﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Account
{
    public class Account : AccountOperation
    {
        public Account(string operation, int account)
        {
            Operation = operation;
            //       Account = account;
        }
        private string Operation { get; set; }
        //  private int Account { get; set; }

        public Account(List<Expenses> expenses, List<Incomes> incomes, List<Withdraw> withdraw, string operation)//, int account)
        {
            Operation = operation;
            //    Account = account;
        }
        public class Incomes : AccountOperation
        {
            public string Month { get; set; }
            private DateTime IncomeTime { get; set; }

            public Incomes(string month, DateTime incomeTime)
            {
                Month = month;
                IncomeTime = incomeTime;
            }
            public Incomes(List<Expenses> expenses, List<Incomes> incomes, List<Withdraw> withdraw, string month, DateTime incomeTime)
            {
                Month = month;
                IncomeTime = incomeTime;
            }
        }
        public class Withdraw : AccountOperation
        {
            private DateTime WithdrawTime { get; set; }
            public Withdraw(List<Expenses> expenses, List<Incomes> incomes, List<Withdraw> withdraw, DateTime withdrawTime)
            {
                WithdrawTime = withdrawTime;
            }

        }
        public class Expenses : AccountOperation
        {
            public string Name { get; set; }
            private DateTime CtreationTime { get; set; }
            private double money { get; set; }
            public Expenses(string name, DateTime creationTime, double Money)
            {
                Name = name;
                creationTime = creationTime;
                money = Money;
            }
        }
    }

    public class AccountOperation
    {
        public List<Account.Incomes> Incomes { get; set; }
        public List<Account.Expenses> Expenses { get; set; }
        public List<Account.Withdraw> Withdraws { get; set; }

        public AccountOperation()
        {
            Incomes = new List<Account.Incomes>();
            Expenses = new List<Account.Expenses>();
            Withdraws = new List<Account.Withdraw>();
        }

        public AccountOperation(List<Account.Expenses> expens, List<Account.Incomes> income, List<Account.Withdraw> withdraw)
        {
            Incomes = income;
            Expenses = expens;
            Withdraws = withdraw;
        }

        public void AddExpenses(Account.Expenses expens) {
            Expenses.Add(expens);
        }
        public void AddIncomes(Account.Incomes incom) {
            Incomes.Add(incom);
        }
        public void AddWithdrow(Account.Withdraw withdraw) {
            Withdraws.Add(withdraw);
        }


    }

    class Program
    {
        static void Main(string[] args)
        {
            var operation1 = new Account("Expenses",12);
            var expenses = new Account.Expenses("Shop",DateTime.Now,50.70);
            operation1.AddExpenses(expenses);
            Console.WriteLine(operation1);
        }
    }
}


