﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Music
{
  
   // public enum MusicStyles {CLASSIC,POP,ROCK,METAL,JAZZ }

    public class Disc
    {
        private List<Track> trackslist = new List<Track>();
        private MusicService service = new MusicService();

        public Disc()
        {
            trackslist.Add(new Track("Skillet - Awake", 3.42, "ROCK"));
            trackslist.Add(new Track("Jena Lee - Mon Ange", 3.52, "ROCK"));
            trackslist.Add(new Track("Enrique Iglesias feat. Pitbull - I like it", 3.49, "POP"));

            service.getTracksList(trackslist);
            service.findByRange(3.43,4.02,trackslist);
        }
    }

    public class Track:Disc {
        private string name;
        private double length;
        private string style;

        public Track(string name, double length, string style) {
            this.name = name;
            this.length = length;
            this.style = style;
        }
        public string getName() { return name; }
        public void setName() { this.name = name; }
        public double getlength() { return length; }
        public void setlength() { this.length = length; }
        public string getstyle() { return style; }
        public void setstyle() { this.style = style; }
        public string fullString() { return "Name: " + getName() + ", Length: " + getlength() + ", Style: " + getstyle(); }
    }



    public class MusicService {


        public void getTracksList(List<Track> trackslist)
        {
            trackslist.ForEach(Console.WriteLine);
        }
        
        public void findByRange(double from, double to, List<Track> trackslist) {
            for (int i = 0; i < trackslist.Count(); i++) {
                if (trackslist.ElementAt(i).getlength() >= from && trackslist.ElementAt(i).getlength() <= to) {
                    Console.WriteLine(trackslist.ElementAt(i).ToString());
                }

            }
        }
        }
    class Program
    {
        static void Main(string[] args)
        {
            var disc = new Disc();
        }
    }
}
    

