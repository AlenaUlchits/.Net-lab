﻿using System;
using System.Collections.Generic;

namespace Lab3_Polynom
{
    class Polynom
    {
        // private double realpart;
        //private double impart;

        public Polynom(double k, double s)
        {
            realpart = k;
            impart = s;
        }

        private double realpart { get; }
        private double impart { get; }

        public static void Add(Polynom a, Polynom b)
        {
            double sumreal = a.realpart + b.realpart;
            double sumim = a.impart + b.impart;
            Console.WriteLine("Sum of real parts: " + sumreal + " sum of imaginary parts:" + sumim);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            var complex1 = new Polynom(2.5, 1.3);
            var complex2 = new Polynom(0.7, 0.9);

            var polynoms = new List<Polynom> { complex1, complex2 };

            Polynom.Add(polynoms[0], polynoms[1]);
            Console.ReadKey();


        }
    }
}
