﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    public interface IFurniture
    {
        double Square ();

    }
    public abstract class AbstractCase : IFurniture {
        public double Square() { return 1; }
    }
public class Bookcase : AbstractCase 
    {
        public int ShelvesAmount { get; set; }
        public int DrawersAmount { get; set; }
        public Bookcase(double width, double height, double length, int shelvesAmount, int drawersAmount) {
            ShelvesAmount = shelvesAmount;
            DrawersAmount = drawersAmount;
        }

    }

    internal class Program
    {
        public static void Main(string[] args)
        {
            IFurniture furniture = new Bookcase(5.0, 40.0, 10.0, 6, 3);

            Console.WriteLine(furniture.Square());

        }
    }
}
